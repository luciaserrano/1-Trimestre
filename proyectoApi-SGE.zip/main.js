const url = 'https://api.disneyapi.dev/characters/25'

fetch(url)
.then(response => response.json() )
.then(data => {

    let element = document.getElementById('elem')
    element.innerHTML = `
    <h3>${data.name}</h3>
    <p>${data._id}</p>
    <img src ='${data.imageUrl}'/>
    <a href='${data.sourceUrl}'>Ir a DisneyPedia</a>

    `;

    console.log(data)
})
.catch(err=>console.log(err))